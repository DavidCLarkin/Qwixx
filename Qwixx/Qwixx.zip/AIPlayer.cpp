// AIPlayer Class
// Author : David Larkin, 20070186

#include <iostream>;
#include "AIPlayer.h";

using namespace std;
 